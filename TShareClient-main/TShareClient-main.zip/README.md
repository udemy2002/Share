<h1>TShare Client</h1>
<p>Thằng này hướng tới người dùng nên dễ dùng hơn, ko cần cài gì, tải code về chạy, ko cần cài nhiều như thằng Server</p>
<p>Mở file TShare.java để chạy(Lưu ý là file TShare.java chứ không phải là file HomePage.java nhé)</p>
<a href="https://github.com/trinhsytuan/TShareServer">Link code thằng Server đây</p>
